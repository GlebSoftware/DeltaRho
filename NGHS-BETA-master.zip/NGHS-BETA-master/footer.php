<!-- classie.js by @desandro: https://github.com/desandro/classie -->
<script src="js/classie.js"></script>
<script src="js/cbpAnimatedHeader.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src='http://code.jquery.com/jquery-1.9.1.js'></script><script src='http://code.jquery.com/ui/1.10.3/jquery-ui.js'></script>

<div class="footer">
	<a href="dashboard" title="Member's Area">Member Dashboard</a><br /><br />
    &copy; North Gwinnett High School Beta Club<br />
    <a href="mailto:nghs.betaclub@gmail.com">nghs.betaclub@gmail.com</a> / Level Creek Road, Suwanee, GA, 30024<br />
    Miranda Simmons and Megan Johnston<br />
    Site Re-Designed By <a href="http://bit.ly/Gleb-Site/" target="_blank">Gleb Alikhver</a><br />
</div>

</body>
</html>

<?php
mysql_free_result($memberInformation);
?>
